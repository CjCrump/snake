const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const box = 20;
const canvasSize = 400;
const rows = canvasSize / box;

let snake = [{ x: 9 * box, y: 9 * box }];
let direction = "RIGHT";
let food = {
    x: Math.floor(Math.random() * rows) * box,
    y: Math.floor(Math.random() * rows) * box,
};

function draw() {
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, canvasSize, canvasSize);

    // Draw food
    ctx.fillStyle = "#00ffea";
    ctx.beginPath();
    ctx.arc(food.x + box/2, food.y + box/2, box/2, 0, Math.PI*2);
    ctx.fill();
    ctx.closePath();

    // Draw snake
    ctx.fillStyle = "#ffd700";
    for (let part of snake) {
        ctx.fillRect(part.x, part.y, box, box);
    }

    // Move snake
    let head = { ...snake[0] };
    switch (direction) {
        case "LEFT":
            head.x -= box;
            break;
        case "UP":
            head.y -= box;
            break;
        case "RIGHT":
            head.x += box;
            break;
        case "DOWN":
            head.y += box;
            break;
    }

    // Check collision
    if (
        head.x < 0 ||
        head.x >= canvasSize ||
        head.y < 0 ||
        head.y >= canvasSize ||
        snake.some((part) => part.x === head.x && part.y === head.y)
    ) {
        alert("Game Over! Score: " + snake.length);
        snake = [{ x: 9 * box, y: 9 * box }];
        direction = "RIGHT";
        return;
    }

    // Check food collision
    if (head.x === food.x && head.y === food.y) {
        food = {
            x: Math.floor(Math.random() * rows) * box,
            y: Math.floor(Math.random() * rows) * box,
        };
    } else {
        snake.pop();
    }

    snake.unshift(head);
    setTimeout(draw, 100);
}

document.addEventListener("keydown", (e) => {
    switch (e.key) {
        case "ArrowLeft":
        case "a":
            if (direction !== "RIGHT") direction = "LEFT";
            break;
        case "ArrowUp":
        case "w":
            if (direction !== "DOWN") direction = "UP";
            break;
        case "ArrowRight":
        case "d":
            if (direction !== "LEFT") direction = "RIGHT";
            break;
        case "ArrowDown":
        case "s":
            if (direction !== "UP") direction = "DOWN";
            break;
    }
});

function changeDirection(dir) {
    if (dir === "UP" && direction !== "DOWN") direction = dir;
    else if (dir === "DOWN" && direction !== "UP") direction = dir;
    else if (dir === "LEFT" && direction !== "RIGHT") direction = dir;
    else if (dir === "RIGHT" && direction !== "LEFT") direction = dir;
}

draw();
